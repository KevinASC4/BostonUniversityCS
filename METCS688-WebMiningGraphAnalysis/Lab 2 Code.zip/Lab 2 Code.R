# Newsgroups Classification with tm
library(tm)


# 1) Select Newsgroup to analyze: 
news_group1 <- ""

# Specify Data Paths 
Doc1.TrainPath <- ""

# 2) Load All Data using tm's DirSource 
Temp1 <- ""
Temp2 <- ""
Temp3 <- ""
Temp4 <- ""

# 3) Create Corpus of only the first 100 documents
doc_count <- 0
Doc.Corpus <- ""
inspect(Doc.Corpus[[n]])

# 4) Create Document-Term Matrix (dtm) of word lengths of at least 2 and word frequency of at least 5 
dtm <- DocumentTermMatrix()

set.seed(1234)

# 5) Split the Document-Term Matrix into Train & Test Data sets
# and Create Classification Labels (Tags)
# Then perform text classification using "KNN" classifier from the package "class".

# 6) Analysis -- Data Frame: Train Data 


# 7 & 8) Create the Confusion Matrix 



# 9) Calculate Precision, Recall & F-score.


# 10) Re-Run your code for another pair of subjects. 

