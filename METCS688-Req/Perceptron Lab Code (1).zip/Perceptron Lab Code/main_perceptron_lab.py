"""
    Program: Iris Flower Dataset Classification Project using Perceptron
        Demonstrates how to use Perceptron as a defined function to classify Iris Dataset.

    Data: Iris Dataset



"""

from app import project_functions as pf
import pandas as pd
import numpy as np
from random import randrange


if __name__ == '__main__':

    # Create a variable iris_data_url and pass to it the following
    # URL: 'https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data'
    # Next load the Iris dataset from this URL
    # Q1: What is the number of rows of this data frame?


    # Q2: What is the name of the second column?


    # 3) Rename the columns of the dataframe to the following
    # Q3: What is the name of the second column now?


    # 4) Create a variable "classes" which contains the unique value of the fifth column
    # Q4: How many different classes are there?


    # 5) Visualize Data by creating a function
    # Visualize the whole dataset
    # Q5: Which flower ('Class_labels') has the longest ....?

    # 6) Modify your code from the previous question to find the value of the shortest ...
    # Q6: Which flower ('Class_labels') has the longest 'Sepal length'?


    # Q7: From the visualization plot, the class ... is well separated from the other two flowers
    # by which feature?


    # Q8:In the python script “project_functions.py” create a function “plot_data” containing the given code.
    # Then insert code in your script “main_perceptron_lab.py” to plot Petal vs Sepal Length:



    # 9) Determine Training Weights of Perceptron
    # Choose features and labels. Specify Learning rate
    # Create dataframe to train the Perceptron on half of the data

    # Q9: What are the weights learned by the perceptron?


    # Q10: Make classification predictions with learned weights of the perceptron, using the given code.




    print("End")